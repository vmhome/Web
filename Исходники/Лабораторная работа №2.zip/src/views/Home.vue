<!-- Каждый элемент во vue представляется в виде компонента. -->
<!-- Каждый компонент состоит из 3-х секций: template (html шаблон), script (js код исполняемый на стр.) -->
<!-- и style секция для специфичных стилей, которые используются внутри template (вместо style лучше создать css файл). -->

<template>
  <div class="home">
    <div class="container">
      <h2 align="center">  Двери в Белгороде с покрытием экошпона! </h2>
      <h3 align="center"> Дополнительную информацию по товару вы можете уточнить у менеджеров магазина. </h3>

      <div class="divider margin_bottom_50">

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-14 Light Sonoma.jpg" height="300"> <br>
            Порта-14 Light Sonoma <br>
            <b> 2230 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-14 Light Sonoma.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>

                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-19.3 Light Sonoma.jpg" height="300"> <br>
            Порта-19.3 Light Sonoma <br>
            <b> 2385 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-19.3 Light Sonoma.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Cappuccino Veralinga.jpg" height="300"> <br>
            Порта-21 Cappuccino Veralinga <br>
            <b> 2570 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Cappuccino Veralinga.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="divider margin_bottom_50">

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Wenge Veralinga.jpg" height="300"> <br>
            Порта-21 Wenge Veralinga <br>
            <b> 3400 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Wenge Veralinga.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Anegri Veralinga.jpg" height="300"> <br>
            Порта-21 Anegri Veralinga <br>
            <b> 3400 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Anegri Veralinga.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Light Sonoma.jpg" height="300"> <br>
            Порта-21 Light Sonoma <br>
            <b> 2570 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Light Sonoma.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="divider margin_bottom_50">

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Grey Veralinga.jpg" height="300"> <br>
            Порта-21 Grey Veralinga <br>
            <b> 3400 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Grey Veralinga.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Snow Veralinga.jpg" height="300"> <br>
            Порта-21 Snow Veralinga <br>
            <b> 3400 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-21 Snow Veralinga.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*35 <br>
                  200*40 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Cappuccino Veralinga СТ-Black Star.jpg" height="300"> <br>
            Порта-22 Cappuccino Veralinga СТ-Black Star <br>
            <b> 3570 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Cappuccino Veralinga СТ-Black Star.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="divider margin_bottom_50">

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Cappuccino Veralinga СТ-Magic Fog.jpg" height="300"> <br>
            Порта-22 Cappuccino Veralinga СТ-Magic Fog <br>
            <b> 2570 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Cappuccino Veralinga СТ-Magic Fog.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Grey Veralinga СТ-Black Star.jpg" height="300"> <br>
            Порта-22 Grey Veralinga СТ-Black Star <br>
            <b> 3570 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Grey Veralinga СТ-Black Star.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Grey Veralinga СТ-Magic Fog.jpg" height="300"> <br>
            Порта-22 Grey Veralinga СТ-Magic Fog <br>
            <b> 3400 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Grey Veralinga СТ-Magic Fog.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="divider margin_bottom_50">

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Snow Veralinga СТ-Black Star.jpg" height="300"> <br>
            Порта-22 Snow Veralinga СТ-Black Star <br>
            <b> 3570 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Snow Veralinga СТ-Black Star.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Snow Veralinga СТ-Magic Fog.jpg" height="300"> <br>
            Порта-22 Snow Veralinga СТ-Magic Fog <br>
            <b> 3400 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Snow Veralinga СТ-Magic Fog.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  190*55 <br>
                  190*60 <br>
                  200*35 <br>
                  200*40 <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="container_doors">
          <div class="img_and_text">
            <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Wenge Veralinga СТ-Black Star.jpg" height="300"> <br>
            Порта-22 Wenge Veralinga СТ-Black Star <br>
            <b> 3570 руб. </b>
          </div>
          <div class="door_info">
            <div class="container_local_findings">
              <div class="divider">
                <div>
                  <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-22 Wenge Veralinga СТ-Black Star.jpg" height="300"> <br>
                </div>
                <div class="margin_left_30">
                  <b> Серия: </b>  Porta X <br>
                  <b> Размеры: </b> <br>
                  200*60 <br>
                  200*70 <br>
                  200*80 <br>
                  200*90 <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="page_number">
        <a class="page_number_this" href="#"> 1 </a>
        <a href="#"> 2 </a>
        <a href="#"> 3 </a>
        <a href="#"> 4 </a>
        <a href="#"> 5 </a>
        <p> ... </p>
        <a href="#"> 16 </a>
      </div>
    </div>
  </div>
</template>


