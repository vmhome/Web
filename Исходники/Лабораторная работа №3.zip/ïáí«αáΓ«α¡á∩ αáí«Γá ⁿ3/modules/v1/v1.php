<?php

namespace app\modules\v1;

use yii\base\Module;

class v1 extends Module {

}