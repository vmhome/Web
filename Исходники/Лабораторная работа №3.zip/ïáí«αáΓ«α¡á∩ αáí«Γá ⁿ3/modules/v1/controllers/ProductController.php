<?php
namespace app\modules\v1\controllers;

class ProductController extends ApiController {
    public function actionHome () {
        $products = [
            [
                'itemsImage' => '../../public/images/doors/interior/eco_wood_veneer/Порта-14 Light Sonoma.jpg',
                'itemsName' => 'Порта-14 Light Sonoma',
                'itemsPrice' => 2230,
                'itemsSeries' => 'Porta X'
            ],
            [
                'itemsImage' =>  '../../public/images/doors/interior/eco_wood_veneer/Порта-19.3 Light Sonoma.jpg',
                'itemsName' => 'Порта-19.3 Light Sonoma',
                'itemsPrice' =>  2385,
                'itemsSeries' =>'Porta X'
            ],
            [
                'itemsImage' => '../../public/images/doors/interior/eco_wood_veneer/Порта-21 Cappuccino Veralinga.jpg',
                'itemsName' => 'Порта-21 Cappuccino Veralinga',
                'itemsPrice' => 2570,
                'itemsSeries' => 'Porta X'
            ]
        ];
        return $products;
    }
}