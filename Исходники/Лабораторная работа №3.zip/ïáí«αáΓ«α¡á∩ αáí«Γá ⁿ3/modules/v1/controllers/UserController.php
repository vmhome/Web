<?php
namespace app\modules\v1\controllers;

class UserController extends ApiController {
    public function actionIndex() {
        $users = [
            [
                'id' => 1,
                'name' => 'Ivan',
                'age' => 23
            ],
            [
                'id' => 2,
                'name' => 'Vasia',
                'age' => 45
            ]
        ];
        return $users;
    }
}
