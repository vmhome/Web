<template>
  <div class="bottom_background">
    <div class="container">

          <h1 class="bottom_info_title"> Panorama </h1>

    </div>
  </div>
</template>

<script>
export default {
name: "compon"
}
</script>

<style scoped>

</style>