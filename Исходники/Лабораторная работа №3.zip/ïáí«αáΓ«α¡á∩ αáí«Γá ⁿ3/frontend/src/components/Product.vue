<template>
  <div class="product">
    <div class="container_doors">
      <div class="img_and_text">
<!--        <img v-bind:src="productParam.itemsImage" height="300"> <br>-->
        <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-14 Light Sonoma.jpg" height="300"> <br>
        {{productParam.itemsName}} <br>
        <b> {{ productParam.itemsPrice }} руб. </b>

      </div>
      <div class="door_info">
        <div class="container_local">
          <div class="divider">
            <div>
              <img src="../../public/images/doors/interior/eco_wood_veneer/Порта-14 Light Sonoma.jpg" height="300"> <br>
            </div>
            <div class="margin_left_30">
              <b> Серия: </b>  {{productParam.itemsSeries}} <br>
              <b> Размеры: </b> <br>
              200*60 <br> 200*70 <br> 200*80 <br> 200*90 <br>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "Product",
    // props принемает на вх. данные из Home.vue items
    props: ['productParam']
  }
</script>