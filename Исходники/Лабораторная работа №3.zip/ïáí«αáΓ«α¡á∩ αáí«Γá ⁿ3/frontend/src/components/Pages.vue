<template>
  <div class="container">
    <div class="page_number">
      <a class="page_number_this" href="#"> 1 </a>
      <a href="#"> 2 </a>
      <a href="#"> 3 </a>
      <a href="#"> 4 </a>
      <a href="#"> 5 </a>
      <p> ... </p>
      <a href="#"> 16 </a>
    </div>
  </div>
</template>

<script>
export default {
  name: "Pages"
}
</script>