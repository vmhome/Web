<template>
    <div class="container">
          <div class="divider">
            <div class="left_ch">
              <p> Логин: </p>
              <p> Пароль: </p>
            </div>
            <div class="right_ch">
              <input type="text" name="login" class="input_reg_in"> <br>	<!-- Поле ввода -->
              <input type="text" name="password" class="input_reg_in"> <br>
            </div>
          </div>
          <br>
          <input type="submit" name="Submit" class="bottom_reg_in">		<!-- Кнопка отправить -->
        <br><br><br>
    </div>

</template>
