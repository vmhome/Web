<template>
  <div class="container">
        <div class="divider">
          <div class="left_ch">
            <p> Логин: </p>
            <p> Имя: </p>
            <p> Фамилия: </p>
            <p> Отчество: </p>
            <p> Телефон: </p>
            <p> e-mail: </p>
            <p> Пароль: </p>
            <p> Повторите пароль: </p>
          </div>
          <div class="right_ch">
            <input type="text" name="login" class="input_reg_in"> <br>
            <input type="text" name="name" class="input_reg_in"> <br>	<!-- Поле ввода -->
            <input type="text" name="surname" class="input_reg_in"> <br>
            <input type="text" name="otch" class="input_reg_in"> <br>
            <input type="text" name="tel" class="input_reg_in"> <br>
            <input type="text" name="mail" class="input_reg_in"> <br>
            <input type="text" name="passwordOne" class="input_reg_in"> <br>
            <input type="text" name="passwordTwo" class="input_reg_in"> <br>
          </div>
        </div>
        <br>
        <input type="submit" name="Submit" class="bottom_reg_in">		<!-- Кнопка отправить -->
    <br><br><br>
  </div>
</template>
