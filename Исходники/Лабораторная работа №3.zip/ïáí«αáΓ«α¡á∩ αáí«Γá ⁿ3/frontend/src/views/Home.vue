<!-- Каждый элемент во vue представляется в виде компонента. -->
<!-- Каждый компонент состоит из 3-х секций: template (html шаблон), script (js код исполняемый на стр.) -->
<!-- и style секция для специфичных стилей, которые используются внутри template (вместо style лучше создать css файл). -->

<template>
  <div class="home">
    <div class="container">
      <h2 align="center">  Двери в Белгороде с покрытием экошпона! </h2>
      <h3 align="center"> Дополнительную информацию по товару вы можете уточнить у менеджеров магазина. </h3>
    </div>

    <div class="container">
      <div class="divider margin_bottom_50">
        <div v-for="item in items">
          <Product v-bind:productParam="item"> </Product>
        </div>
      </div>
    </div>

    <Pages></Pages>
  </div>
</template>


<script>
  import Axios from 'axios';
  import Product from "@/components/Product";
  import Pages from "@/components/Pages";
  export default {
    name: 'Home',
    components: {Product, Pages},
    data() {
      return {
        items: []
      }
    },
    created() {
      const instance = Axios.create({
        baseURL: 'http://localhost:1199/v1'
      });

      instance.get('/product/home') // product - контроллер home - метод
          .then((response) => this.items = response.data)

    }
  }
</script>

