<template>
  <div id="app">
        <header class="header">
      <div class="enter">
        <div class="container divider">
          <div>
          </div>
          <div id="nav">
            <!-- Вместо to="/файл" можно использовать v-bind:to="{name: 'Имя'}" -->
            <!-- Так мы не будем привзываться к конкретному пути -->
            <router-link v-bind:to="{name: 'Enter'}" class="bottom"> Вход </router-link>
            <router-link to="/registration" class="bottom"> Регистрация </router-link>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="header_top">
          <div>
            <a href="#" rel="lightbox">
              <img class="header_top_icon" src="../public/images/vk_new.png" height="25" />
            </a>
            <a href="#">
              <img class="header_top_icon" src="../public/images/inst_new.png" height="25" />
            </a>
          </div>
          <div>г. Название, ул. Название, Номер строения </div>
        </div>

        <div class="header_top">
          <div></div>
          <div> <a href="tel:+7..."> +7 (4722) xx-xx-xx </a> </div>
        </div>

        <div class="header_top">
          <div></div>
          <div><a href="+7..."> +7 (xxx) xxx-xx-xx </a> </div>
        </div>

        <div class="price">
          <div> </div>
          <div> xxx@mail.ru </div>
        </div>

        <div class="header_top">
          <div></div>
          <div> Пн-Пт 10-19 | Сб-Вс 10-16 </div>
        </div>

        <div class="header_center"> </div>

        <div class="header_bottom">
          <nav class="menu">
            <ul>
              <li> <router-link to="/" class="margin_lrtb"> <img src="../public/images/home.png" height="30" /> </router-link> </li>
              <li> <a class="margin_lrtb" href="doors/1.html"> Двери </a>
                <ul>
                  <li> <a href="doors/input/1.html"> Входные </a>
                    <ul>
                      <li> <a href="doors/input/metal/1.html"> Металлические </a> </li>
                      <li> <a href="doors/input/plastic/1.html"> Пластиковые </a> </li>
                      <li> <a href="doors/input/fire_fighting/1.html"> Противопожарные </a> </li>
                    </ul>
                  </li>
                  <li> <a href="doors/interior/1.html"> Межкомнатные </a>
                    <ul>
                      <li> <a href="doors/interior/veneer/1.html"> Шпонированные </a> </li>
                      <li> <a href="doors/interior/eco_wood_veneer/1.html"> Экошпон </a> </li>
                      <li> <a href="doors/interior/laminate/1.html"> Ламинированные </a> </li>
                      <li> <a href="doors/interior/pvc_film/1.html"> ПВХ пленка </a> </li>
                      <li> <a href="doors/interior/array/1.html"> Массив дерева </a> </li>
                      <li> <a href="doors/interior/painted/1.html"> Окрашенные (эмаль) </a> </li>
                      <li> <a href="doors/interior/sliding/1.html"> Раздвижные </a> </li>
                      <li> <a href="doors/interior/folding/1.html"> Складные </a> </li>
                      <li> <a href="doors/interior/glass/1.html"> Стеклянные </a> </li>
                      <li> <a href="doors/interior/building/1.html"> Строительные </a> </li>
                      <li> <a href="doors/interior/aqua/1.html"> Аква </a> </li>
                      <li> <a href="doors/interior/bathhouse/1.html"> Для бани </a> </li>
                    </ul>
                  </li>
                </ul>
              </li>

              <li> <a class="margin_lrtb" href="windows/1.html"> Окна </a>
                <ul>
                  <li> <a href="windows/one/1.html"> Одностворчатые </a> </li>
                  <li> <a href="windows/two/1.html"> Двустворчатые </a> </li>
                  <li> <a href="windows/three/1.html"> Трехстворчатые </a> </li>
                  <li> <a href="windows/pvc/1.html"> Балконный блок ПВХ </a> </li>
                </ul>
              </li>

              <li> <a class="margin_lrtb" href="findings/1.html"> Фурнитура </a>
                <ul>
                  <li> <a href="findings/door_handle/1.html"> Дверные ручки </a>
                    <ul>
                      <li> <a href="findings/door_handle/sliding/1.html"> Для раздвижных дверей </a> </li>
                      <li> <a href="findings/door_handle/plowing/1.html"> Для распашных дверей </a> </li>
                      <li> <a href="findings/door_handle/glass/1.html"> Для стеклянных дверей </a> </li>
                    </ul>
                  </li>
                  <li> <a href="findings/door_hinge/1.html"> Дверные петли </a>
                    <ul>
                      <li> <a href="findings/door_hinge/glass/1.html"> Для стеклянных дверей </a> </li>
                      <li> <a href="findings/door_hinge/without_frame/1.html"> Петли без врезки </a> </li>
                    </ul>
                  </li>
                  <li> <a href="findings/locks_and_mechanisms/1.html"> Замки и механизмы </a>
                    <ul>
                      <li> <a href="findings/locks_and_mechanisms/sliding/1.html"> Для раздвижных систем </a> </li>
                      <li> <a href="findings/locks_and_mechanisms/glass/1.html"> Для стеклянных дверей </a> </li>
                      <li> <a href="findings/locks_and_mechanisms/iron/1.html"> Со стальным язычком </a> </li>
                    </ul>
                  </li>
                  <li> <a href="findings/video_eye/1.html"> Видеоглазки </a> </li>
                  <li> <a href="findings/door_closer/1.html"> Доводчики дверей </a> </li>
                  <li> <a href="findings/additionally/1.html"> Допоплнительно для раздвижных дверей </a> </li>
                  <li> <a href="findings/bells/1.html"> Звонки </a> </li>
                  <li> <a href="findings/limiters/1.html"> Ограничители дверей </a> </li>
                </ul>
              </li>
              <li> <a class="margin_lrtb" href="arches/1.html"> Арки </a>
                <ul>
                  <li> <a href="arches/without_finishing/1.html"> Арки без отделки </a> </li>
                  <li> <a href="arches/pvc/1.html"> Арки ПВХ </a> </li>
                  <li> <a href="arches/veneer/1.html"> Арки шпонированные </a> </li>
                  <li> <a href="arches/eco_wood_veneer/1.html"> Порталы Эко шпон </a> </li>
                  <li> <a href="arches/enamel/1.html"> Эмалит </a> </li>
                </ul>
              </li>
              <li> <a class="margin_lrtb" href="services/1.html"> Услуги </a> </li>
              <li> <a class="margin_lrtb" href="aboutshop/1.html"> О магазине </a> </li>
              <li> <a class="margin_lrtb" href="stocks/1.html"> Акции </a> </li>
              <li> <a class="margin_lrtb" href="articles/1.html"> Статьи </a> </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>

    <compon></compon>

    <router-view/> <!-- То, что возвращают компоненты (из папки views) -->

    <div class="bottom_background">
      <div class="container">
        <div class="divider">
          <div class="container_local">
            <h1 class="bottom_info_title"> Panorama </h1>
            <div class="bottom_info_left"> Интернет-магазин дверей </div>
          </div>

          <div class="container_local">
            <div class="bottom_info_right">
              <div> Индекс г. Название, ул. Название, Номер строения </div>
              <div> (Примерное расположение) </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import Compon from "@/components/compon";
export default {
  components: {Compon},
  // Данная конструкция делает запрост к url 'http://localhost:1199/v1' + '/product/home'
  // и возвращает response
  data () {
    return {
      items: []
    }
  },
  created () {
    const instance = Axios.create({
      baseURL: 'http://localhost:1199/v1'
    });
    instance.get('/product/home')
    .then((response) => this.items = response.data)
  }
}
</script>