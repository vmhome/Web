// Здесь определены зависимости между страницами

import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Enter from '../views/Enter.vue'
import Registration from '../views/Registration.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/', // / - корневой каталог
    name: 'Home',
    component: Home
  },
  {
    path: '/enter',
    name: 'Enter',
    component: Enter
  },
  {
    path: '/registration',
    name: 'Registration',
    component: Registration
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
